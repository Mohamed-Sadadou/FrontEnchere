export const trendyProducts = [
  {
    image: "/download.jpeg",
    name: "iPhone 13 Pro Max ",
    shop: {
      profile: "/person.jpeg",
      name: "OYA Store",
    },
    price: 225000,
  },
  {
    image: "/download.jpeg",
    name: "T-Shirt",
    shop: {
      profile: "/person.jpeg",
      name: "my_shirtsdz",
    },
    price: 1600,
  },
  {
    image: "/download.jpeg",
    name: "airpods 3rd Gen",
    shop: {
      profile: "/person.jpeg",
      name: "Apple Store",
    },
    price: 24000,
  },
];
