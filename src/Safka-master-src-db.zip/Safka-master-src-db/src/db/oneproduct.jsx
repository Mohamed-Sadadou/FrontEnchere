export const oneproduct = {
  productphotoone: "../img/figmaphoto.PNG",
  productphototow: "../img/figmaphoto.PNG",
  productphotothree: "../img/figmaphoto.PNG",
  productphotocolorone: "../img/figmaphoto.PNG",
  productphotocolortow: "../img/figmaphoto.PNG",
  productname: "Metal Analog Wrist Watch GS19063",
  productgrade: "4.5",
  productowner: "Malux Digital Shop",
  profilepic: "../img/profiletemp.jpg",
  productadress: "Alger",
  productprice: "24000",
  sallergrade: "4.0",
  sallerreviewsnumber: "62k",
  productdescription:
    "the best the bestthe best the bestthe best the bestthe best the bestthe best the bestthe best the bestthe best the best",
};
