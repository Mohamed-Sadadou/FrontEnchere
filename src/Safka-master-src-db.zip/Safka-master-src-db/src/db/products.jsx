export const products = [
  {
    img: "/download.jpeg",
    name: "iPhone 13 Pro Max",
    shop: {
      profile: "/person.jpeg",
      name: "OYA Store",
    },
    price: 225000,
  },
  {
    img: "/download.jpeg",
    name: "T-Shirt",
    shop: {
      profile: "/person.jpeg",
      name: "my_shirtsdz",
    },
    price: 1600,
  },
  {
    img: "/download.jpeg",
    name: "airpods 3rd Gen",
    shop: {
      profile: "/person.jpeg",
      name: "Apple Store",
    },
    price: 24000,
  },
  {
    img: "/download.jpeg",
    name: "308 nouveau",
    shop: {
      profile: "/person.jpeg",
      name: "peugeot show room",
    },
    price: 8000000,
  },
  // {
  //   img: "/download.jpeg",
  //   name: "",
  //   shop: {
  //     profile: "/person.jpeg",
  //     name: "",
  //   },
  //   price: 0,
  // },
  // {
  //   img: "/download.jpeg",
  //   name: "",
  //   shop: {
  //     profile: "/person.jpeg",
  //     name: "",
  //   },
  //   price: 0,
  // },
  // {
  //   img: "/download.jpeg",
  //   name: "",
  //   shop: {
  //     profile: "/person.jpeg",
  //     name: "",
  //   },
  //   price: 0,
  // },
  // {
  //   img: "/download.jpeg",
  //   name: "",
  //   shop: {
  //     profile: "/person.jpeg",
  //     name: "",
  //   },
  //   price: 0,
  // },
  // {
  //   img: "/download.jpeg",
  //   name: "",
  //   shop: {
  //     profile: "/person.jpeg",
  //     name: "",
  //   },
  //   price: 0,
  // },
];
