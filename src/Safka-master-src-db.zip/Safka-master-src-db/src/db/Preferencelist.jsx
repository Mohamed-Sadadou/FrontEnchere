export const Preferencelist = [
  {
    name: "Electronics",
    sousCat: ["sousCat1", "sousCat2", "sousCat3", "sousCat4", "sousCat5"],
  },
  {
    name: "Mobile",
    sousCat: ["sousCat1", "sousCat2", "sousCat3", "sousCat4", "sousCat5"],
  },
  {
    name: "Beauty",
    sousCat: ["sousCat1", "sousCat2", "sousCat3", "sousCat4", "sousCat5"],
  },
  {
    name: "Electronics",
    sousCat: ["sousCat1", "sousCat2", "sousCat3", "sousCat4", "sousCat5"],
  },
  {
    name: "cooking",
    sousCat: ["sousCat1", "sousCat2", "sousCat3", "sousCat4", "sousCat5"],
  },
  {
    name: "home deco",
    sousCat: ["sousCat1", "sousCat2", "sousCat3", "sousCat4", "sousCat5"],
  },
];
