export const delivery = [
  {
    name: "Fast Delivery",
    image: "/Delv1.jpg",
    localisation: "Alger",
    rating: 4.5,
  },
  {
    name: "Your Delivery",
    image: "/deliv2.jpg",
    localisation: "Alger",
    rating: 4.5,
  },
];
