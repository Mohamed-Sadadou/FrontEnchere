export const trendyStores = [
  {
    image: "/person.jpeg",
    name: "my_shirtsdz",
    location: "Alger",
    rating: 4.5,
  },
  {
    image: "/person.jpeg",
    name: "OYA Store",
    location: "Alger",
    rating: 4.5,
  },
  {
    image: "/person.jpeg",
    name: "Apple Store",
    rating: 4.5,
  },
];
